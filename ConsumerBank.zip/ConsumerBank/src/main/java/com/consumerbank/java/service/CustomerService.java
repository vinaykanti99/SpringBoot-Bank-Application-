package com.consumerbank.java.service;



import java.util.List;

import org.springframework.http.HttpStatus;

import com.consumerbank.java.dto.CustomerDeleteResponseDTO;
import com.consumerbank.java.dto.CustomerRequestDTO;
import com.consumerbank.java.dto.CustomerResponse;
import com.consumerbank.java.dto.CustomerResponseDTO;
import com.consumerbank.java.dto.CustomerUpdateRequestDTO;
import com.consumerbank.java.dto.CustomerUpdateResponseDTO;

public interface CustomerService {

	String saveCustomerData(CustomerRequestDTO customerRequestDto);

	List<CustomerResponse> getCustomerDetails(String name);


	List<CustomerResponseDTO> getCustomerDetails();

	CustomerUpdateResponseDTO updateCustomerDetails(Integer customerId, CustomerUpdateRequestDTO customerUpdateDto);

	CustomerDeleteResponseDTO delete(Integer customerId);



}
