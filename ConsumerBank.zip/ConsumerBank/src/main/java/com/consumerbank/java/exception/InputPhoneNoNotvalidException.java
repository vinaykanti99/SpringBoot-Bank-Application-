package com.consumerbank.java.exception;

public class InputPhoneNoNotvalidException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputPhoneNoNotvalidException(String message)
	{
		super(message);
	}

}
