package com.consumerbank.java.service;



import java.util.List;

import com.consumerbank.java.dto.AccountDeleteResponseDTO;
import com.consumerbank.java.dto.AccountRequestDTO;
import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.dto.AccountUpdateRequestDTO;
import com.consumerbank.java.dto.AccountUpdateResponseDTO;
import com.consumerbank.java.dto.BeneficiaryDTO;

public interface AccountService {

	AccountResponseDTO saveAccountData(AccountRequestDTO accountRequestDto);

	List<AccountResponseDTO> getAccountDetails(Integer customerId);

	AccountUpdateResponseDTO updateAccountDetails(AccountUpdateRequestDTO accountUpdateRequestDto, Long accountNumber);

	AccountDeleteResponseDTO deleteAccountDetails(Long accountNumber);



	

}
