package com.consumerbank.java.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class BeneficiaryDTO {
	
	@NotNull(message="beneficiaryName can't be empty")
	@NotEmpty(message ="beneficiaryName can't be empty")
	private String beneficiaryName;
	
	@NotNull(message="account number can't be empty")
	@NotEmpty(message ="account number can't be empty")
	private Long accountNumber;
	@NotNull(message="beneficiary account number can't be empty")
	@NotEmpty(message ="beneficiary account can't be empty")
	private Long beneficiaryAccount;
	
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getBeneficiaryAccount() {
		return beneficiaryAccount;
	}
	public void setBeneficiaryAccount(Long beneficiaryAccount) {
		this.beneficiaryAccount = beneficiaryAccount;
	}
	
	

}
