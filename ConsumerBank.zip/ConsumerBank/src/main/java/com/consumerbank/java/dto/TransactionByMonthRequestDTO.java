package com.consumerbank.java.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class TransactionByMonthRequestDTO {
	
	@NotNull(message="month number can't be null")
	@NotEmpty(message="month can't be empty")
	private int fromMonth;
	@NotNull(message="month number can't be null")
	@NotEmpty(message="month can't be empty")
	private int toMonth;
	public int getFromMonth() {
		return fromMonth;
	}
	public void setFromMonth(int fromMonth) {
		this.fromMonth = fromMonth;
	}
	public int getToMonth() {
		return toMonth;
	}
	public void setToMonth(int toMonth) {
		this.toMonth = toMonth;
	}
	

}
