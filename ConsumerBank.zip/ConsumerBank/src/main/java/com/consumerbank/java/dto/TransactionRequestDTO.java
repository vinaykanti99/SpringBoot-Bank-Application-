package com.consumerbank.java.dto;

import java.sql.Date;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;



public class TransactionRequestDTO {
	
	@NotNull(message ="balance can't be empty")
	@Min(value = 1000, message = "Balace can't be less than 1000")
	private double amount;
	@NotEmpty(message="transaction type can't be empty")
	@NotNull(message="transaction type can't be null")
	private String transactionType;
	@NotNull(message="accountId can't be empty")
	@NotEmpty(message="accountId can't be empty")
	private Integer accountId;
	@NotNull(message="date can't be empty")
	@NotEmpty(message="date can't be empty")
	private Date transactionDate;
	@NotNull(message="fromaccountnumber can't be empty")
	@NotEmpty(message="toaccountnumber can't be empty")
	private Long fromAccountNo;
	@NotNull(message="toaccountnumber can't be empty")
	@NotEmpty(message="toaccountnumber can't be empty")
	private Long toAccountNo;
	
	
	public Long getFromAccountNo() {
		return fromAccountNo;
	}
	public void setFromAccountNo(Long fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}
	public Long getToAccountNo() {
		return toAccountNo;
	}
	public void setToAccountNo(Long toAccountNo) {
		this.toAccountNo = toAccountNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	

}
