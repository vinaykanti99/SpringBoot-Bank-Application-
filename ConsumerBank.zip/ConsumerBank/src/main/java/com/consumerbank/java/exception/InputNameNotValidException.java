package com.consumerbank.java.exception;

public class InputNameNotValidException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputNameNotValidException(String message)
	{
		super(message);
	}

}
