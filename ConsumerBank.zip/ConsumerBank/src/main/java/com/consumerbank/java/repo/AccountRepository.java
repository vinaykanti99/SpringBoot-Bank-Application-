package com.consumerbank.java.repo;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.consumerbank.java.dto.AccountResponse;
import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.entity.Account;
import com.consumerbank.java.entity.Transaction;

public interface AccountRepository extends CrudRepository<Account, Integer> {
	
	List<Account> findByCustomerId(Integer customerId);
	Account findBycustomerId(Integer customerId);
	
	//DTO projection using query
	@Query(value = "select new com.consumerbank.java.dto.AccountResponseDTO(a.accountId, a.accountNumber) from Account a")
	List<AccountResponseDTO> findAccounts();
	
	//DTO projection using class
	AccountResponse findByAccountNumber(Long accountNumber);
	
	Account findByAccountNumberEquals(Long fromAccountNumber);
	Optional<Account> findByaccountNumber(Long accountNumber);
	
	
	
	

}
