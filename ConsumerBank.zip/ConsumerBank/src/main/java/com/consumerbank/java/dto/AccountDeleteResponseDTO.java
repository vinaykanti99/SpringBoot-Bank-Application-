package com.consumerbank.java.dto;

public class AccountDeleteResponseDTO {
	
	private Integer customerId;
	private String message;
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	


}
