package com.consumerbank.java.dto;

import java.sql.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class TransferAmountRequestDTO {
	
	@NotNull(message="account number can't be null")
	@NotEmpty(message="account Number can't be empty")
	private Long fromAccountNo;
	@NotNull(message="account number can't be null")
	@NotEmpty(message="account number can't be empty")
    private Long toAccountNo;
	@NotNull(message="transaction type can't be null")
    @NotEmpty(message="transaction type can't be empty")
	private String transactionType;
	

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	private Date transactionDate;
    private double amount;

	public Long getFromAccountNo() {
		return fromAccountNo;
	}

	public void setFromAccountNo(Long fromAccountNo) {
		this.fromAccountNo = fromAccountNo;
	}

	public Long getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(Long toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	

}
