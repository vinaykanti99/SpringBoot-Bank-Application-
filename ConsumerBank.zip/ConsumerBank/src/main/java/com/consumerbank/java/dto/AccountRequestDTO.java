package com.consumerbank.java.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


public class AccountRequestDTO {
	
	@NotNull(message ="accountnumber can't be null")
	@NotEmpty(message ="accountnumber can't be empty")
	private Long accountNumber;
	@NotNull(message ="accountholder name can't be null")
	@NotEmpty(message ="accountholder name can't be empty")
	private String accountHolderName;
	@NotNull(message ="balance can't be null")
	@Min(value = 1000, message = "Balace can't be less than 1000")
	private double balance;
	@NotEmpty(message ="account type can't be empty")
	@NotNull(message ="account type can't be null")
	private String accountType;
	@NotEmpty(message ="customerId can't be empty")
	@NotNull(message ="customerId can't be null")
	private Integer customerId;
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	

}
