package com.consumerbank.java.controller;

import java.sql.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.dto.BeneficiaryRequestDTO;
import com.consumerbank.java.dto.TransactionByMonthRequestDTO;
import com.consumerbank.java.dto.TransactionDateResponseDTO;
import com.consumerbank.java.dto.TransactionDeleteresponseDTO;
import com.consumerbank.java.dto.TransactionRequestDTO;
import com.consumerbank.java.dto.TransactionResponseDTO;
import com.consumerbank.java.dto.TransactionUpdateResponseDTO;
import com.consumerbank.java.dto.TransactionsDateRequestDTO;
import com.consumerbank.java.dto.TransferAmountRequestDTO;
import com.consumerbank.java.dto.TransferAmountResponseDTO;
import com.consumerbank.java.entity.Transaction;
import com.consumerbank.java.repo.TransactionRepository;
import com.consumerbank.java.service.Transactionservice;

@RestController
@Validated
public class TransactionController {
	
	@Autowired
	Transactionservice transactionService;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@PostMapping("/transactions")
	public ResponseEntity<TransactionResponseDTO> saveTransactionDetails(@Valid @RequestBody TransactionRequestDTO transactionRequestDto)
	{
		TransactionResponseDTO transactionResponseDTO=transactionService.saveTransactionDetails(transactionRequestDto);
		return new ResponseEntity<TransactionResponseDTO>(transactionResponseDTO,HttpStatus.ACCEPTED);
	}
	
	
	
	@GetMapping("/transactions")
	public ResponseEntity<List<TransactionResponseDTO>> getTransactinDetails(@NotNull(message="account number can't be null")@RequestParam Long fromAccountNo)
	{
		List<TransactionResponseDTO> transactionResponseDTO=transactionService.getTransactiondetails(fromAccountNo);
		return new ResponseEntity<List<TransactionResponseDTO>>(transactionResponseDTO,HttpStatus.ACCEPTED);

	}
	
	
	@DeleteMapping("/transactions")
	public ResponseEntity<TransactionDeleteresponseDTO> deleteTransactionDetails(@NotNull(message="transaction id can't be null")@RequestParam Integer transactionId)
	{
		TransactionDeleteresponseDTO transactionDeleteresponseDto=transactionService.deleteTransactionDetails(transactionId);
		return new ResponseEntity<TransactionDeleteresponseDTO>(transactionDeleteresponseDto,HttpStatus.ACCEPTED);

	}
	
	@GetMapping("/transactions/transactionsbydate")
	public List<Transaction> transactionsByDate(@Valid @RequestBody TransactionsDateRequestDTO transactionsDateRequestDto)
	{
		Date fromDate=transactionsDateRequestDto.getFromDate();
		Date toDate=transactionsDateRequestDto.getToDate();
		Integer accountId=transactionsDateRequestDto.getAccountId();
		List<Transaction> list=transactionRepository.findByDate(fromDate, toDate,accountId);
		return list;
		
	}
	
	@PostMapping("/transactions/beneficiarytransfer")
	public ResponseEntity<String> makeBeneficiaryTransaction(@Valid @RequestBody BeneficiaryRequestDTO beneficiaryRequestDto)
	{
		transactionService.makeBeneficiaryTransaction(beneficiaryRequestDto);
		return new ResponseEntity<String>("Money transfered",HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/transcations/transactionsByMonth")
	public ResponseEntity<List<Transaction>> transactionsByMonth(@RequestBody TransactionByMonthRequestDTO transactionByMonthRequestDto)
	{
		List<Transaction> response=transactionService.getTransactionsBymonth(transactionByMonthRequestDto);
		return new ResponseEntity<List<Transaction>>(response,HttpStatus.ACCEPTED);
	}

}
