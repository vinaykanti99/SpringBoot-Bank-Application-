package com.consumerbank.java.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.consumerbank.java.dto.AccountDeleteResponseDTO;
import com.consumerbank.java.dto.AccountRequestDTO;
import com.consumerbank.java.dto.AccountResponse;
import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.dto.AccountUpdateRequestDTO;
import com.consumerbank.java.dto.AccountUpdateResponseDTO;
import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.repo.AccountRepository;
import com.consumerbank.java.service.AccountService;

@RestController
@Validated
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	AccountRepository accountRepository;
	
	@PostMapping("/accounts")
	public ResponseEntity<AccountResponseDTO> saveAccountData(@Valid @RequestBody AccountRequestDTO accountRequestDto)
	{
		AccountResponseDTO accountResponseDto=accountService.saveAccountData(accountRequestDto);
		return new ResponseEntity<AccountResponseDTO>(accountResponseDto,HttpStatus.CREATED); 
		
	}
	
	@GetMapping("/accounts")
	public ResponseEntity<List<AccountResponseDTO>> getAccountDetails(@Valid @RequestParam Integer customerId)
	{
		List<AccountResponseDTO> accountResponseDTO=accountService.getAccountDetails(customerId);
		return new ResponseEntity<List<AccountResponseDTO>>(accountResponseDTO,HttpStatus.ACCEPTED);
	}
	
	@PutMapping("/accounts")
	public ResponseEntity<AccountUpdateResponseDTO> updateAccountDetails(@Valid @RequestBody AccountUpdateRequestDTO accountUpdateRequestDto,@RequestParam Long accountNumber)
	{
		AccountUpdateResponseDTO accountUpdateResponseDTO=accountService.updateAccountDetails(accountUpdateRequestDto,accountNumber);
		
		return new ResponseEntity<AccountUpdateResponseDTO>(accountUpdateResponseDTO,HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/accounts")
	public ResponseEntity<AccountDeleteResponseDTO> deleteAccountDetails(@RequestParam Long accountNumber)
	{
		AccountDeleteResponseDTO accountDeleteResponseDTO=accountService.deleteAccountDetails(accountNumber);
		return new ResponseEntity<AccountDeleteResponseDTO>(accountDeleteResponseDTO,HttpStatus.ACCEPTED);
	}
	
	//DTO Projection using query
	
	@GetMapping("/accounts/accountslist")
	public ResponseEntity<List<AccountResponseDTO>> getAllAccounts()
	{
		return new ResponseEntity<List<AccountResponseDTO>>(accountRepository.findAccounts(),HttpStatus.OK);
	}
	
	//DTO Projection using class
	
	@GetMapping("/accounts/{accountNumber}")
	public ResponseEntity<AccountResponse> findAccountByAccountNumber(@NotNull(message="account number can't be empty")@PathVariable Long accountNumber)
	{
		return new ResponseEntity<AccountResponse>(accountRepository.findByAccountNumber(accountNumber),HttpStatus.OK);
	}
	
	
	

}
