package com.consumerbank.java.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.entity.BeneficiaryAccount;
import com.consumerbank.java.repo.BeneficiaryRepository;
import com.consumerbank.java.service.BeneficiaryService;

@RestController
@Validated
public class BeneficiaryController {
	
	@Autowired
	BeneficiaryRepository beneficiaryRepository;
	
	@Autowired
	BeneficiaryService beneficiaryService;
	
	@PostMapping("/addbeneficiary")
	public ResponseEntity<String> addBeneficiary(@Valid @RequestBody BeneficiaryDTO beneficiaryDto)
	{
		beneficiaryService.addBeneficiary(beneficiaryDto);
		return new ResponseEntity<String>("Beneficiary added",HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/allbeneficiary")
	public ResponseEntity<List<BeneficiaryAccount>> getAllAccounts()
	{
		List<BeneficiaryAccount> list=beneficiaryService.getAllAccounts();
		return new ResponseEntity<List<BeneficiaryAccount>>(list,HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/deletebeneficiary/{beneficiaryId}")
	public ResponseEntity<String> deleteBeneficiary(@NotNull(message="The id cant be null") @PathVariable Integer beneficiaryId)
	{
		beneficiaryService.deleteBeneficiary(beneficiaryId);
		return new ResponseEntity<String>("Account deleted successfully",HttpStatus.ACCEPTED);
	}

}
