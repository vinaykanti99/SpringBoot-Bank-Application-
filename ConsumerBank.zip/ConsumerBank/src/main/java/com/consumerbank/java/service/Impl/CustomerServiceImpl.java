package com.consumerbank.java.service.Impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.consumerbank.java.dto.CustomerDeleteResponseDTO;
import com.consumerbank.java.dto.CustomerRequestDTO;
import com.consumerbank.java.dto.CustomerResponse;
import com.consumerbank.java.dto.CustomerResponseDTO;
import com.consumerbank.java.dto.CustomerUpdateRequestDTO;
import com.consumerbank.java.dto.CustomerUpdateResponseDTO;
import com.consumerbank.java.entity.Customer;
import com.consumerbank.java.exception.CustomerNotFoundException;
import com.consumerbank.java.exception.InputAadharNotvalidException;
import com.consumerbank.java.exception.InputNameNotValidException;
import com.consumerbank.java.exception.InputPhoneNoNotvalidException;
import com.consumerbank.java.repo.CustomerRepository;
import com.consumerbank.java.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public String saveCustomerData(CustomerRequestDTO customerRequestDto) {
		// TODO Auto-generated method stub
		Customer customer=customerRepository.findByCustomerName(customerRequestDto.getCustomerName());
		Customer customer1=customerRepository.findByphoneNo(customerRequestDto.getPhoneNo());
		Customer customer2=customerRepository.findByaadharNo(customerRequestDto.getAadharNo());
		if(customer !=null)
		{
			throw new InputNameNotValidException("Check the entered customer name");
		}
		if(customer1 !=null)
		{
			throw new InputAadharNotvalidException("Check the entered phone number");
		}
		if(customer2 !=null)
		{
			throw new InputPhoneNoNotvalidException("Check the entered aadhar number");
		}

		Customer customer3=new Customer();
		BeanUtils.copyProperties(customerRequestDto, customer3);
		Customer finalcustomer=customerRepository.save(customer3);
		if(finalcustomer !=null)
		{
			return "true";
		}
		return "false";


	}

	@Override
	public List<CustomerResponseDTO> getCustomerDetails() {

		List<CustomerResponseDTO> clist=new ArrayList<>();
		Iterator it= customerRepository.findAll().iterator();
		while(it.hasNext())
		{
			CustomerResponseDTO response=new CustomerResponseDTO();
			BeanUtils.copyProperties(it.next(), response);
			clist.add(response);
		}
		return clist;


	}

	@Override
	public List<CustomerResponse> getCustomerDetails(String name) {
		// TODO Auto-generated method stub
		/*List<CustomerResponseDTO> clist=new ArrayList<>();
		List<Customer> list=customerRepository.findByCustomerNameContaining(name);

		for(Customer customer:list)
		{
			CustomerResponseDTO response=new CustomerResponseDTO();
			BeanUtils.copyProperties(customer, response);
			clist.add(response);
		}*/

		return customerRepository.findByCustomerNameContaining(name);
	}



	@Override
	public CustomerUpdateResponseDTO updateCustomerDetails(Integer customerId, CustomerUpdateRequestDTO customerUpdateDto) {
		// TODO Auto-generated method stub
		if(customerRepository.findById(customerId).isPresent())
		{
			Customer customer=customerRepository.findById(customerId).get();
			BeanUtils.copyProperties(customerUpdateDto, customer);
			Customer updatedCustomer=customerRepository.save(customer);
			CustomerUpdateResponseDTO customerResponseDTO=new CustomerUpdateResponseDTO();
			BeanUtils.copyProperties(updatedCustomer, customerResponseDTO);

			return customerResponseDTO;
		}
		throw new CustomerNotFoundException("Customer doesn't exist for this id"+" "+" "+customerId);  
	}

	@Override
	public CustomerDeleteResponseDTO delete(Integer customerId) {
		// TODO Auto-generated method stub
		if(customerRepository.findById(customerId).isPresent())
		{
			CustomerDeleteResponseDTO customerDeleteResponseDTO=new CustomerDeleteResponseDTO();
			customerRepository.deleteById(customerId);
			customerDeleteResponseDTO.setCustomerId(customerId);
			customerDeleteResponseDTO.setMessage("Customer Deleted Successfully");

			return customerDeleteResponseDTO;

		}
		throw new CustomerNotFoundException("Customer doesn't exist for this id"+" "+" "+customerId);  

	}

}
