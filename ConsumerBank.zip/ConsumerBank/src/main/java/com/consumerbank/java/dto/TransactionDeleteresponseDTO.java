package com.consumerbank.java.dto;

public class TransactionDeleteresponseDTO {
	
	
	private String transactionType;
	private String message;
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
