package com.consumerbank.java.service.Impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.dto.BeneficiaryRequestDTO;
import com.consumerbank.java.dto.CustomerResponseDTO;
import com.consumerbank.java.dto.TransactionByMonthRequestDTO;
import com.consumerbank.java.dto.TransactionDateResponseDTO;
import com.consumerbank.java.dto.TransactionDeleteresponseDTO;
import com.consumerbank.java.dto.TransactionRequestDTO;
import com.consumerbank.java.dto.TransactionResponseDTO;
//import com.consumerbank.java.dto.TransactionUpdateRequestDTO;
import com.consumerbank.java.dto.TransactionUpdateResponseDTO;
import com.consumerbank.java.dto.TransactionsDateRequestDTO;
import com.consumerbank.java.dto.TransferAmountRequestDTO;
import com.consumerbank.java.dto.TransferAmountResponseDTO;
import com.consumerbank.java.entity.Account;
import com.consumerbank.java.entity.BeneficiaryAccount;
import com.consumerbank.java.entity.Customer;
import com.consumerbank.java.entity.Transaction;
import com.consumerbank.java.exception.AccountNotFoundException;
import com.consumerbank.java.exception.CustomerNotFoundException;
import com.consumerbank.java.exception.TransactionNotFoundException;
import com.consumerbank.java.repo.AccountRepository;
import com.consumerbank.java.repo.BeneficiaryRepository;
import com.consumerbank.java.repo.CustomerRepository;
import com.consumerbank.java.repo.TransactionRepository;
import com.consumerbank.java.service.Transactionservice;

@Service
public class TransactionServiceImpl implements Transactionservice {

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	BeneficiaryRepository beneficiaryRepository;

	@Override
	public TransactionResponseDTO saveTransactionDetails(TransactionRequestDTO transactionRequestDto) {
		// TODO Auto-generated method stub
		Optional<Account> optionalAccount=accountRepository.findByaccountNumber(transactionRequestDto.getFromAccountNo());
		Optional<Account> optionalAccount1=accountRepository.findByaccountNumber(transactionRequestDto.getToAccountNo());
		if(optionalAccount.isPresent() && optionalAccount1.isPresent()) 
		{
			Account account=accountRepository.findByAccountNumberEquals(transactionRequestDto.getFromAccountNo());
			Account account1=accountRepository.findByAccountNumberEquals(transactionRequestDto.getToAccountNo());

			double amount=transactionRequestDto.getAmount();
			if(account.getBalance()<amount)
			{
				throw new RuntimeException("Amount is greater than balance");
			}
			else
			{
				account.setBalance(account.getBalance()-amount);
				accountRepository.save(account);
				account1.setBalance(account1.getBalance()+amount);
				accountRepository.save(account1);
			}
			Transaction transaction=new Transaction();
			BeanUtils.copyProperties(transactionRequestDto, transaction);
			transactionRepository.save(transaction);
			TransactionResponseDTO transactionResponseDto=new TransactionResponseDTO();
			BeanUtils.copyProperties(transaction, transactionResponseDto);
			return transactionResponseDto;
		}
		throw new AccountNotFoundException("Account doesn't exist for this number"+" "+transactionRequestDto.getFromAccountNo());

	}

	@Override
	public List<TransactionResponseDTO> getTransactiondetails(Long fromAccountNo) {
		// TODO Auto-generated method stub
		Optional<Account> optionalAccount=accountRepository.findByaccountNumber(fromAccountNo);
		if(optionalAccount.isPresent()) 
		{
			List<TransactionResponseDTO> transactionResponseList=new ArrayList<>();
			List<Transaction> transactionList=transactionRepository.findByfromAccountNo(fromAccountNo);

			for(Transaction transaction:transactionList)
			{
				TransactionResponseDTO transactionResponseDTO=new TransactionResponseDTO();
				BeanUtils.copyProperties(transaction, transactionResponseDTO);
				transactionResponseList.add(transactionResponseDTO);
			}

			return transactionResponseList;

		}
		throw new AccountNotFoundException("Account doesn't exist for this number"+" "+fromAccountNo);


	}

	@Override
	public TransactionDeleteresponseDTO deleteTransactionDetails(Integer transactionId) {
		// TODO Auto-generated method stub
		Optional<Transaction> optimalTransaction=transactionRepository.findById(transactionId);
		if(optimalTransaction.isPresent())
		{
			Transaction transaction=transactionRepository.findById(transactionId).get();
			TransactionDeleteresponseDTO deleteresponseDto=new TransactionDeleteresponseDTO();
			BeanUtils.copyProperties(transaction, deleteresponseDto);
			transactionRepository.delete(transaction);
			deleteresponseDto.setMessage("Deleted");
			return deleteresponseDto;
		}
		throw new TransactionNotFoundException("Transaction doesn't exist for this id"+" "+transactionId);

	}


	@Override
	public void makeBeneficiaryTransaction(BeneficiaryRequestDTO beneficiaryRequestDto) {
		// TODO Auto-generated method stub

		Account accountNumber;
		Account beneficiaryAccount;

		Optional<BeneficiaryAccount> sendAccount=beneficiaryRepository.findByAccountNumber(beneficiaryRequestDto.getAccountNumber(),beneficiaryRequestDto.getBeneficiaryAccount());
		if(sendAccount.isPresent())
		{
			accountNumber=accountRepository.findByAccountNumberEquals(beneficiaryRequestDto.getAccountNumber());
			beneficiaryAccount=accountRepository.findByAccountNumberEquals(beneficiaryRequestDto.getBeneficiaryAccount());

		}
		else
		{
			throw new RuntimeException("thowing exception to check valid beneficiary");

		}
		double amount=beneficiaryRequestDto.getAmount();
		if(accountNumber.getBalance()<1000 && accountNumber.getBalance()<amount)
		{
			throw new RuntimeException("thowing exception transaction can't be done");

		}
		else
		{
			accountNumber.setBalance(accountNumber.getBalance()-amount);
			accountRepository.save(accountNumber);
			beneficiaryAccount.setBalance(beneficiaryAccount.getBalance()+amount);
			accountRepository.save(beneficiaryAccount);
		}

		Transaction transaction=new Transaction();
		BeanUtils.copyProperties(beneficiaryRequestDto, transaction);
		transaction.setTransactionType("Beneficiary transfer");
		long now = System.currentTimeMillis();
		Date date = new Date(now);
		transaction.setTransactionDate(date);
		transaction.setAccountId(accountNumber.getAccountId());
		transactionRepository.save(transaction);




	}

	@Override
	public List<Transaction> getTransactionsBymonth(TransactionByMonthRequestDTO transactionByMonthRequestDto) {
		// TODO Auto-generated method stub
		List<Transaction> list=transactionRepository.findTransactionByMonth(transactionByMonthRequestDto.getFromMonth(),transactionByMonthRequestDto.getToMonth());
		return list;
	}




}
