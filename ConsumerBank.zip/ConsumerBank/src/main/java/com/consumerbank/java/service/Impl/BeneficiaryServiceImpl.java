package com.consumerbank.java.service.Impl;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.entity.Account;
import com.consumerbank.java.entity.BeneficiaryAccount;
import com.consumerbank.java.exception.AccountNotFoundException;
import com.consumerbank.java.repo.AccountRepository;
import com.consumerbank.java.repo.BeneficiaryRepository;
import com.consumerbank.java.service.BeneficiaryService;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {
	
	@Autowired
	BeneficiaryRepository beneficiaryRepository;
	
	@Autowired
	AccountRepository accountRepository;

	@Override
	public Boolean addBeneficiary(BeneficiaryDTO beneficiaryDto) {
		// TODO Auto-generated method stub
		Account account=accountRepository.findByAccountNumberEquals(beneficiaryDto.getAccountNumber());
		Account account1=accountRepository.findByAccountNumberEquals(beneficiaryDto.getBeneficiaryAccount());
        BeneficiaryAccount account3=beneficiaryRepository.findBybeneficiaryName(beneficiaryDto.getBeneficiaryName());
        if(account !=null)
        {
        	throw new AccountNotFoundException("Enter the valid account number");
        }
        if(account1 !=null)
        {
        	throw new AccountNotFoundException("Enter the valid beneficiary account number");
        }
        if(account3 !=null)
        {
        	throw new InputMismatchException("Check the entered Beneficiary name");
        }
		BeneficiaryAccount beneficiaryAccount=new BeneficiaryAccount();
		BeanUtils.copyProperties(beneficiaryDto, beneficiaryAccount);
		beneficiaryRepository.save(beneficiaryAccount);
		return true;
		
	}

	@Override
	public List<BeneficiaryAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		List<BeneficiaryAccount> list=beneficiaryRepository.findAll();
		return list;
	}

	@Override
	public void deleteBeneficiary(@NotNull(message = "The id cant be null") Integer beneficiaryId) {
		// TODO Auto-generated method stub
		Optional<BeneficiaryAccount> account=beneficiaryRepository.findById(beneficiaryId);
		if(account.isPresent())
		{
			beneficiaryRepository.deleteById(beneficiaryId);
		}
		throw new RuntimeException("Check the entered beneficiaryId");
	}

}
