package com.consumerbank.java.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class BeneficiaryRequestDTO {
	
	@NotNull(message="account number can't be empty")
	@NotEmpty(message ="account number can't be empty")
	private Long accountNumber;
	@NotNull(message="beneficiary account number can't be empty")
	@NotEmpty(message ="beneficiary account can't be empty")
	private Long beneficiaryAccount;
	@NotNull(message ="balance can't be null")
	@Min(value = 1000, message = "Balace can't be less than 1000")
	@NotEmpty(message ="amount can't be empty")
	private double amount;
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getBeneficiaryAccount() {
		return beneficiaryAccount;
	}
	public void setBeneficiaryAccount(Long beneficiaryAccount) {
		this.beneficiaryAccount = beneficiaryAccount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	

}
