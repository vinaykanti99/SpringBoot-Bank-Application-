package com.consumerbank.java.dto;

public class AccountResponse {
	
	private Long accountNumber;
	private double balance;
	private String accountType;
	private Integer customerId;
	public AccountResponse(Long accountNumber, double balance, String accountType, Integer customerId) {
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.accountType = accountType;
		this.customerId = customerId;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	
	

}
