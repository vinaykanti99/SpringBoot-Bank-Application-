package com.consumerbank.java.repo;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.consumerbank.java.entity.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer> {
	
	List<Transaction> findByAccountId(Integer accountId);
	
	@Query("select a from Transaction a where accountId=:z AND transactionDate BETWEEN :x AND :y")
	List<Transaction> findByDate(@Param("x")Date fromDate,@Param("y")Date toDate,@Param("z")Integer accountId);

	List<Transaction> findByfromAccountNo(Long fromAccountNo);
    
	@Query("select a from Transaction a where transactiondate(dt) BETWEEN :x AND :y")
	List<Transaction> findTransactionByMonth(@Param("x")int fromMonth, @Param("y")int toMonth);

}
