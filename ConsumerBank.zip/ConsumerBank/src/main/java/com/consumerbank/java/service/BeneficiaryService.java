package com.consumerbank.java.service;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.entity.BeneficiaryAccount;

public interface BeneficiaryService {

	Boolean addBeneficiary(BeneficiaryDTO beneficiaryDto);

	List<BeneficiaryAccount> getAllAccounts();

	void deleteBeneficiary(@NotNull(message = "The id cant be null") Integer beneficiaryId);

}
