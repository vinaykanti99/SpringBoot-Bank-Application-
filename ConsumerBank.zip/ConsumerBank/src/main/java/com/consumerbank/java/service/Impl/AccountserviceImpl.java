package com.consumerbank.java.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.consumerbank.java.dto.AccountDeleteResponseDTO;
import com.consumerbank.java.dto.AccountRequestDTO;
import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.dto.AccountUpdateRequestDTO;
import com.consumerbank.java.dto.AccountUpdateResponseDTO;
import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.entity.Account;
import com.consumerbank.java.entity.Customer;
import com.consumerbank.java.exception.AccountNotFoundException;
import com.consumerbank.java.exception.CustomerNotFoundException;
import com.consumerbank.java.repo.AccountRepository;
import com.consumerbank.java.repo.CustomerRepository;
import com.consumerbank.java.service.AccountService;
@Service
public class AccountserviceImpl implements AccountService{
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public AccountResponseDTO saveAccountData(AccountRequestDTO accountRequestDto) {
		
		Optional<Customer> optionalCustomer=customerRepository.findById(accountRequestDto.getCustomerId());
		if(optionalCustomer.isPresent()) 
		{
		Account account=new Account();
		BeanUtils.copyProperties(accountRequestDto, account);
		account=accountRepository.save(account);
		AccountResponseDTO accountResponseDto=new AccountResponseDTO();
		BeanUtils.copyProperties(account, accountResponseDto);
		return accountResponseDto;
		}
		throw new CustomerNotFoundException("Customer doesn't exist for this id"+" "+accountRequestDto.getCustomerId());
		
	}

	@Override
	public List<AccountResponseDTO> getAccountDetails(Integer customerId) {
		// TODO Auto-generated method stub
		Optional<Customer> optionalCustomer=customerRepository.findById(customerId);
		if(optionalCustomer.isPresent())
		{
			List<Account> accountList=accountRepository.findByCustomerId(customerId);
			List<AccountResponseDTO> accountResponseDtoList=new ArrayList<AccountResponseDTO>();
			for(Account account:accountList)
			{
				AccountResponseDTO accountResponseDto=new AccountResponseDTO();
	            BeanUtils.copyProperties(account, accountResponseDto);
	            accountResponseDtoList.add(accountResponseDto);

			}
            return accountResponseDtoList;
		}
		throw new CustomerNotFoundException("Customer doesn't exist for this id"+" "+customerId);

		
		
	}

	@Override
	public AccountUpdateResponseDTO updateAccountDetails(AccountUpdateRequestDTO accountUpdateRequestDto,
			Long accountNumber) {
		Optional<Account> optionalAccount=accountRepository.findByaccountNumber(accountNumber);
		if(optionalAccount.isPresent())
		{
			Account account=accountRepository.findByAccountNumberEquals(accountNumber);
			BeanUtils.copyProperties(accountUpdateRequestDto, account);
			Account updatedAccount=accountRepository.save(account);
			AccountUpdateResponseDTO accountUpdateResponseDTO=new AccountUpdateResponseDTO();
			BeanUtils.copyProperties(updatedAccount, accountUpdateResponseDTO);
			accountUpdateResponseDTO.setMessage("Account Details Updated");
			return accountUpdateResponseDTO;
		}
		throw new AccountNotFoundException("Account doesn't exist for this number"+" "+accountNumber);

		
	}

	@Override
	public AccountDeleteResponseDTO deleteAccountDetails(Long accountNumber) {
		// TODO Auto-generated method stub
		Optional<Account> optionalAccount=accountRepository.findByaccountNumber(accountNumber);

		if(optionalAccount.isPresent())
		{
			Account account=accountRepository.findByAccountNumberEquals(accountNumber);
			AccountDeleteResponseDTO accountDeleteResponseDTO=new AccountDeleteResponseDTO();
			BeanUtils.copyProperties(account, accountDeleteResponseDTO);
			accountDeleteResponseDTO.setMessage("Account Deleted Successfully");
			accountRepository.delete(account);
			return accountDeleteResponseDTO;
			
		}
		throw new AccountNotFoundException("Account doesn't exist for this number"+" "+accountNumber);

		
	}

	
	

}
