package com.consumerbank.java.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class AccountUpdateRequestDTO {
	
	@NotNull(message ="balance can't be null")
	@Min(value = 1000, message = "Balace can't be less than 1000")
	@NotEmpty(message ="balance can't be empty")
	private double balance;
	@NotEmpty(message ="account type can't be empty")
	@NotNull(message ="account type can't be null")
	private String accountType;
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	


}
