package com.consumerbank.java.service;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.dto.BeneficiaryRequestDTO;
import com.consumerbank.java.dto.TransactionByMonthRequestDTO;
import com.consumerbank.java.dto.TransactionDateResponseDTO;
import com.consumerbank.java.dto.TransactionDeleteresponseDTO;
import com.consumerbank.java.dto.TransactionRequestDTO;
import com.consumerbank.java.dto.TransactionResponseDTO;
//import com.consumerbank.java.dto.TransactionUpdateRequestDTO;
import com.consumerbank.java.dto.TransactionUpdateResponseDTO;
import com.consumerbank.java.dto.TransactionsDateRequestDTO;
import com.consumerbank.java.dto.TransferAmountRequestDTO;
import com.consumerbank.java.dto.TransferAmountResponseDTO;
import com.consumerbank.java.entity.Transaction;

public interface Transactionservice {

	TransactionResponseDTO saveTransactionDetails(TransactionRequestDTO transactionRequestDto);

	List<TransactionResponseDTO> getTransactiondetails(Long fromAccountNo);
    
	TransactionDeleteresponseDTO deleteTransactionDetails(Integer transactionId);


	void makeBeneficiaryTransaction(BeneficiaryRequestDTO beneficiaryRequestDto);

	List<Transaction> getTransactionsBymonth(TransactionByMonthRequestDTO transactionByMonthRequestDto);




}
