package com.consumerbank.java.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.consumerbank.java.dto.CustomerResponse;
import com.consumerbank.java.entity.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Integer> {
	
	//List<Customer> findByCustomerNameContaining(String name);
	
	List<CustomerResponse> findByCustomerNameContaining(String name);

     Customer findByCustomerName(String name);
     
     Customer findByphoneNo(String phoneNo);

	Customer findByaadharNo(String aadharNo);

	
   


}
