package com.consumerbank.java.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class CustomerUpdateRequestDTO {
	
	@NotEmpty(message="customer name can't be empty")
	@NotNull(message="customer name can't be null")
	private String customerName;
	@NotEmpty(message="phone number can't be empty")
	@NotNull(message="phone number can't be null")
	private String phoneNo;
	@NotEmpty(message="address can't be empty")
	@NotNull(message="address can't be null")
	private String address;
	@NotEmpty(message="aadhar can't be empty")
	@NotNull(message="aadhar can't be null")
	private String aadharNo;
	
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
