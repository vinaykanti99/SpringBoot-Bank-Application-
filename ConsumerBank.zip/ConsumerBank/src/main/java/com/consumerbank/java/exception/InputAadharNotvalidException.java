package com.consumerbank.java.exception;

public class InputAadharNotvalidException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InputAadharNotvalidException(String message)
	{
		super(message);
	}

}
