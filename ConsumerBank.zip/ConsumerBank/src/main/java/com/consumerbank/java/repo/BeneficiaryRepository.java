package com.consumerbank.java.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.consumerbank.java.entity.BeneficiaryAccount;


@Repository
public interface BeneficiaryRepository extends JpaRepository<BeneficiaryAccount, Integer> {

	@Query(value = "select a from BeneficiaryAccount a where accountNumber =:x AND beneficiaryAccount =:y" )
	Optional<BeneficiaryAccount> findByAccountNumber(@Param("x")Long accountNumber,@Param("y")Long beneficiaryAccount);

	BeneficiaryAccount findBybeneficiaryName(String beneficiaryName);
    
	
	
  
	
}
