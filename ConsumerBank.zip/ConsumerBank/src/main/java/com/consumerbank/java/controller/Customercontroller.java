package com.consumerbank.java.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.internal.util.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.consumerbank.java.dto.CustomerDeleteResponseDTO;
import com.consumerbank.java.dto.CustomerRequestDTO;
import com.consumerbank.java.dto.CustomerResponse;
import com.consumerbank.java.dto.CustomerResponseDTO;
import com.consumerbank.java.dto.CustomerUpdateRequestDTO;
import com.consumerbank.java.dto.CustomerUpdateResponseDTO;
import com.consumerbank.java.service.CustomerService;

import ch.qos.logback.classic.Logger;

@RestController
@Validated
public class Customercontroller {
	
	@Autowired
	CustomerService customerService;
	
	org.slf4j.Logger logger=org.slf4j.LoggerFactory.getLogger(Customercontroller.class);
	
	@PostMapping("/customers")
	public ResponseEntity<String> saveCustomerData(@Valid @RequestBody CustomerRequestDTO customerRequestDto)
	{
		logger.info("Saving Customers Details");
		String response=customerService.saveCustomerData(customerRequestDto);
		if(response.equalsIgnoreCase("true"))
		return new ResponseEntity<String>("Customer Data Save Successfully",HttpStatus.ACCEPTED);

		return new ResponseEntity<String>("Customer Data Save Unsccessfully",HttpStatus.NOT_ACCEPTABLE);
		
	}
	
	@GetMapping("/customers")
	public ResponseEntity<List<CustomerResponse>> getCustomerDetails(@NotEmpty(message = "name can't be empty")@RequestParam String name)
	{
		logger.info("Getting Customers Details based on name");
		List<CustomerResponse> list=new ArrayList<>();
		if(name != null)
		{
			list= customerService.getCustomerDetails(name);
		}
		return new ResponseEntity<List<CustomerResponse>>(list,HttpStatus.ACCEPTED);

	}
	
	@GetMapping("/customers/customerslist")
	public ResponseEntity<List<CustomerResponseDTO>> getCustomerDetails()
	{
		logger.debug("Getting all the customers list");
		List<CustomerResponseDTO> list=customerService.getCustomerDetails();
		return new ResponseEntity<List<CustomerResponseDTO>>(list,HttpStatus.ACCEPTED);
		
	}
	
	@PutMapping("/customers")
	public ResponseEntity<CustomerUpdateResponseDTO> updateCustomerdetails(@Valid @RequestBody CustomerUpdateRequestDTO customerUpdateDto,@RequestParam Integer customerId)
	{
		logger.info("Updating customer details using the customerid");
		return new ResponseEntity<CustomerUpdateResponseDTO>(customerService.updateCustomerDetails(customerId,customerUpdateDto),HttpStatus.ACCEPTED);

		
	}
	
	@DeleteMapping("/customers")
	public ResponseEntity<CustomerDeleteResponseDTO> deleteCustomer(@NotNull(message="customerId can't be empty")@RequestParam Integer customerId)
	{
		logger.info("Deleting the customer details based on customerid");
		return new ResponseEntity<CustomerDeleteResponseDTO>(customerService.delete(customerId), HttpStatus.ACCEPTED);
		
	}
}
