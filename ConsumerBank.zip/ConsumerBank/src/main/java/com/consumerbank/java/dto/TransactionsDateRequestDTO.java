package com.consumerbank.java.dto;

import java.sql.Date;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class TransactionsDateRequestDTO {
	
	@NotEmpty(message="date shouldn't be empty")
	@NotNull(message="date can't be null")
	private Date fromDate;
	@NotNull(message="date can't be null")
	@NotEmpty(message="date shouldn't be empty")
    private Date toDate;
	@NotNull(message="account id can't be empty")
	@NotEmpty(message="accountId shouldn't be empty")
	private Integer accountId;
	@NotNull(message="accountnumber can't be empty")
	@NotEmpty(message="accountnumber shouldn't be empty")
	private Long accountNumber;
	
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	

}
