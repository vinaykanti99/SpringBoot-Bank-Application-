package com.consumerbank.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumerBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerBankApplication.class, args);
	}

}
