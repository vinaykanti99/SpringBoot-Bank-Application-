package com.consumerbank.java.dto;

public class TransactionUpdateResponseDTO {
	

	private Integer accountId;
	private String message;
	
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
