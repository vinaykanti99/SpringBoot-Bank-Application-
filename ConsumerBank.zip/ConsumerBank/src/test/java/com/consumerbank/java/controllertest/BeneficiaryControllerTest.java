package com.consumerbank.java.controllertest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.consumerbank.java.controller.AccountController;
import com.consumerbank.java.controller.BeneficiaryController;
import com.consumerbank.java.dto.AccountRequestDTO;
import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.dto.BeneficiaryDTO;
import com.consumerbank.java.entity.BeneficiaryAccount;
import com.consumerbank.java.service.AccountService;
import com.consumerbank.java.service.BeneficiaryService;

@ExtendWith(MockitoExtension.class)
public class BeneficiaryControllerTest {
	
	@Mock
	BeneficiaryService beneficiaryService;;
	
	@InjectMocks
	BeneficiaryController beneficiaryController;
	
	BeneficiaryDTO beneficiaryDto;
	
	@BeforeEach
	public void setUp() {
		beneficiaryDto=new BeneficiaryDTO();
		beneficiaryDto.setBeneficiaryName("vinay");
		beneficiaryDto.setAccountNumber(61002545L);
		beneficiaryDto.setBeneficiaryAccount(123456L);
		
	}
	
	@Test
	public void addBeneficiary()
	{
		when(beneficiaryService.addBeneficiary(beneficiaryDto)).thenReturn(true);
		ResponseEntity<String> response=beneficiaryController.addBeneficiary(beneficiaryDto);
		assertEquals("Beneficiary added",response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());
	}
	
	@Test
	public void getBeneficiary()
	{
		List<BeneficiaryAccount> list = null;
		when(beneficiaryService.getAllAccounts()).thenReturn(list);
		ResponseEntity<List<BeneficiaryAccount>> response = beneficiaryController.getAllAccounts();
		assertEquals(beneficiaryController.getAllAccounts().getBody(),response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());
	}
	
	

}
