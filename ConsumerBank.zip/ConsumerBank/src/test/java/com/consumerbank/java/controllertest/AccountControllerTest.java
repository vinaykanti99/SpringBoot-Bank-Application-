package com.consumerbank.java.controllertest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.consumerbank.java.controller.AccountController;
import com.consumerbank.java.controller.Customercontroller;
import com.consumerbank.java.dto.AccountDeleteResponseDTO;
import com.consumerbank.java.dto.AccountRequestDTO;
import com.consumerbank.java.dto.AccountResponseDTO;
import com.consumerbank.java.dto.AccountUpdateRequestDTO;
import com.consumerbank.java.dto.AccountUpdateResponseDTO;
import com.consumerbank.java.dto.CustomerRequestDTO;
import com.consumerbank.java.service.AccountService;

@ExtendWith(MockitoExtension.class)
public class AccountControllerTest {
	
	@Mock
	AccountService accountService;
	
	@InjectMocks
	AccountController accountController;
	
	AccountRequestDTO accountRequestDto;
	AccountResponseDTO accountResponsesDto;
	
	@BeforeEach
	public void setUp() {
		accountRequestDto = new AccountRequestDTO();
		accountRequestDto.setAccountHolderName("vinay");
		accountRequestDto.setAccountNumber(61002545L);
		accountRequestDto.setAccountType("SA");
		accountRequestDto.setBalance(9000);
		accountRequestDto.setCustomerId(4);

		accountResponsesDto = new AccountResponseDTO();
		accountResponsesDto.setAccountNumber(61002545L);
		accountResponsesDto.setAccountId(1);
		
	}
	
	@Test
	public void saveAccount()
	{
		AccountResponseDTO accountResponseDto=null;
		when(accountService.saveAccountData(accountRequestDto)).thenReturn(accountResponseDto);
		ResponseEntity<AccountResponseDTO> response=accountController.saveAccountData(accountRequestDto);
		assertEquals(accountController.saveAccountData(accountRequestDto).getBody(), response.getBody());
		assertEquals(HttpStatus.CREATED,response.getStatusCode());
	}
	
	@Test
	public void getAccounts()
	{
		Integer customerId = null;
		List<AccountResponseDTO> accountResponseList = null;
		when(accountService.getAccountDetails(customerId)).thenReturn(accountResponseList);
		ResponseEntity<List<AccountResponseDTO>> response=accountController.getAccountDetails(customerId);
		assertEquals(accountController.getAccountDetails(customerId).getBody(), response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());

	}
	@Test
	public void updateAccount()
	{
		AccountUpdateRequestDTO accountUpdateRequestDto = null;
		Long accountNumber = null;
		AccountUpdateResponseDTO accountUpdateResponseDTO = null;
		when(accountService.updateAccountDetails(accountUpdateRequestDto, accountNumber)).thenReturn(accountUpdateResponseDTO);
		ResponseEntity<AccountUpdateResponseDTO> response=accountController.updateAccountDetails(accountUpdateRequestDto, accountNumber);
		assertEquals(accountController.updateAccountDetails(accountUpdateRequestDto, accountNumber).getBody(),response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());

	}
	
	@Test
	public void deleteAccount()
	{
		AccountDeleteResponseDTO accountDeleteResponseDTO=null;
		Long accountNumber = null;
		when(accountService.deleteAccountDetails(accountNumber)).thenReturn(accountDeleteResponseDTO);
		ResponseEntity<AccountDeleteResponseDTO> response=accountController.deleteAccountDetails(accountNumber);
		assertEquals(accountController.deleteAccountDetails(accountNumber).getBody(),response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());

	}

}
