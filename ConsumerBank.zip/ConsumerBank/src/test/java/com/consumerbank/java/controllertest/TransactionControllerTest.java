package com.consumerbank.java.controllertest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.consumerbank.java.controller.TransactionController;
import com.consumerbank.java.dto.TransactionDeleteresponseDTO;
import com.consumerbank.java.dto.TransactionRequestDTO;
import com.consumerbank.java.dto.TransactionResponseDTO;
import com.consumerbank.java.dto.TransferAmountRequestDTO;
import com.consumerbank.java.dto.TransferAmountResponseDTO;
import com.consumerbank.java.entity.Transaction;
import com.consumerbank.java.service.Transactionservice;
import com.consumerbank.java.service.Impl.TransactionServiceImpl;

@ExtendWith(MockitoExtension.class)
public class TransactionControllerTest {
	
	@Mock
	Transactionservice transactionService;

	@InjectMocks
	TransactionController transactionController;

	Transaction transaction;

	@BeforeEach
	void setUp() throws ParseException {
		transaction=new Transaction();
		transaction.setTransactionId(1);
		transaction.setTransactionType("Debit");
		transaction.setAmount(1900);
		transaction.setAccountId(1);
		transaction.setFromAccountNo(456789L);
		transaction.setToAccountNo(345627L);
		long now = System.currentTimeMillis();
        Date date = new Date(now);
		transaction.setTransactionDate(date);
	}
	
	@Test
	public void saveTransaction()
	{
		TransactionRequestDTO transactionRequestDto = null;
		TransactionResponseDTO transactionResponseDto=null;
		when(transactionService.saveTransactionDetails(transactionRequestDto)).thenReturn(transactionResponseDto);
		ResponseEntity<TransactionResponseDTO> response=transactionController.saveTransactionDetails(transactionRequestDto);
		assertEquals(transactionController.saveTransactionDetails(transactionRequestDto).getBody(),response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());
		
	}
	
	@Test
	public void getTransactions()
	{
		List<TransactionResponseDTO> transactionResponseList=null;
		Long fromAccountNo = null;
		when(transactionService.getTransactiondetails(fromAccountNo)).thenReturn(transactionResponseList);
		ResponseEntity<List<TransactionResponseDTO>> response = transactionController.getTransactinDetails(fromAccountNo);
		assertEquals(transactionController.getTransactinDetails(fromAccountNo).getBody(),response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());

	}
	
	@Test
	public void deleteTransaction()
	{
		Integer transactionId = null;
		TransactionDeleteresponseDTO deleteresponseDto=null;
		when(transactionService.deleteTransactionDetails(transactionId)).thenReturn(deleteresponseDto);
		ResponseEntity<TransactionDeleteresponseDTO> response=transactionController.deleteTransactionDetails(transactionId);
		assertEquals(transactionController.deleteTransactionDetails(transactionId).getBody(),response.getBody());
		assertEquals(HttpStatus.ACCEPTED,response.getStatusCode());

	}
	
	

}
