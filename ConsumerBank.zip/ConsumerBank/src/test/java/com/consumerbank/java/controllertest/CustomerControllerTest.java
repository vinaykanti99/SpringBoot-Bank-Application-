package com.consumerbank.java.controllertest;

import static org.junit.Assert.assertThrows;
//import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.consumerbank.java.controller.Customercontroller;
import com.consumerbank.java.dto.CustomerDeleteResponseDTO;
import com.consumerbank.java.dto.CustomerRequestDTO;
import com.consumerbank.java.dto.CustomerResponseDTO;
import com.consumerbank.java.dto.CustomerUpdateRequestDTO;
import com.consumerbank.java.dto.CustomerUpdateResponseDTO;
import com.consumerbank.java.entity.Customer;
import com.consumerbank.java.exception.InputNameNotValidException;
import com.consumerbank.java.service.CustomerService;
import com.consumerbank.java.service.Impl.CustomerServiceImpl;
import com.sun.xml.bind.v2.runtime.output.StAXExStreamWriterOutput;

import junit.framework.Assert;


@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {

	@Mock
	CustomerService customerService;

	@InjectMocks
	Customercontroller customerController;

	CustomerRequestDTO customerRequestDTO;
	List<CustomerResponseDTO> customerResponseDTO;


	@BeforeEach
	public void setUp() {
		customerRequestDTO = new CustomerRequestDTO();
		customerRequestDTO.setCustomerName("Vinay");
		customerRequestDTO.setPhoneNo("8179046511");
		customerRequestDTO.setAddress("Bengaluru");
		customerRequestDTO.setAadharNo("644054367");
	}
    @Test
	@DisplayName("Save Customer Data")
	public void saveCustomerDataTest() {
		//context
		when(customerService.saveCustomerData(customerRequestDTO))
		.thenReturn("true");
        //event
		ResponseEntity<String> result = customerController.saveCustomerData(customerRequestDTO);
        //outcome
		assertEquals("Customer Data Save Successfully", result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
	}
    
    @SuppressWarnings("deprecation")
	@Test
    @DisplayName("Name exception")
    public void InputNameNotvalidException() 
    {
    	
		CustomerRequestDTO customerRequestDto = null;
		when(customerService.saveCustomerData(customerRequestDto)).thenThrow(InputNameNotValidException.class);
		ResponseEntity<String> response = customerController.saveCustomerData(customerRequestDto);
    	Assertions.assertEquals(InputNameNotValidException.class, response.getBody());
    	//assertThrows(InputNameNotValidException.class,customerController.saveCustomerData(customerRequestDto));
    	
    }
	
	@Test
	@DisplayName("getting customer data")
	public void getCustomerDetailsTest()
	{
		when(customerService.getCustomerDetails()).thenReturn(customerResponseDTO);
		ResponseEntity<List<CustomerResponseDTO>> result=customerController.getCustomerDetails();
	
		assertEquals(customerController.getCustomerDetails().getBody(), result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
	}
	
	@Test
	@DisplayName("update customer data")
	public void updateDetailsTest()
	{
		Integer customerId = null;
		CustomerUpdateRequestDTO customerUpdateDto = null;
		CustomerUpdateResponseDTO customerUpdateResponseDto = null;
		when(customerService.updateCustomerDetails(customerId, customerUpdateDto)).thenReturn(customerUpdateResponseDto);
		ResponseEntity<CustomerUpdateResponseDTO> result=customerController.updateCustomerdetails(customerUpdateDto, customerId);
		assertEquals(customerController.updateCustomerdetails(customerUpdateDto, customerId).getBody(), result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
	}
	
	@Test
	@DisplayName("delete customer")
	public void delete()
	{
	
		CustomerDeleteResponseDTO customerDeleteResponseDTO = null;
		Integer customerId = null;
		when(customerService.delete(customerId)).thenReturn(customerDeleteResponseDTO);
		ResponseEntity<CustomerDeleteResponseDTO> result=customerController.deleteCustomer(customerId);
		assertEquals(customerController.deleteCustomer(customerId).getBody(), result.getBody());
		assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());

	}



	
}